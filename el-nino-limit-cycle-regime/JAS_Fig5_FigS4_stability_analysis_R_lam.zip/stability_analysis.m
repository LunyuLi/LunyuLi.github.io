% clear
clc
s=1/3;
sigma=0.5;
R=1.001:0.001:5;
lam=0.001:0.001:1.2;
%% zonally asymmetric equilibrium
for i=1:1200
    for j=1:4000
       m=lam(i)*R(j)-s-1;
       n=4*s*(R(j)-1);
       x=m+1+sqrt(m^2+n);
       %盛金公式
       a=1;
       b=-((x-1)*(6*lam(i)*R(j)-x-3)/(4*s)+R(j)-x-sigma-1);
       c=-((x-1)*(4*sigma*R(j)*lam(i)+6*lam(i)*R(j)-sigma*(x+3)-(3*x+1))/(4*s)+(R(j)-x)*(sigma+1)-sigma);
       d=-((x-1)*(4*sigma*R(j)*lam(i)-sigma*(3*x+1))/(4*s)+sigma*(R(j)-x));
       A=b*b-3*a*c;     
       B=b*c-9*a*d;     
       C=c*c-3*b*d;     
       DET = B*B - 4*A*C; 
       if (A == 0) && (B == 0)
            X1(i,j)= -c/b; 
            X2(i,j)=X1(i,j);
            X3(i,j)=X1(i,j);
            X4(i,j)=0;
            X5(i,j)=0;
       end
       if DET >0
          Y1 = A*b + 1.5*a*(-B + sqrt(DET));
          Y2 = A*b + 1.5*a*(-B - sqrt(DET));
          y1 = nthroot(Y1,3);  y2 = nthroot(Y2,3); %这里取Y1和Y2的立方根
          X1(i,j) = (-b-y1-y2)/(3*a);
          X2(i,j) = (-b + 0.5*(y1 + y2))/(3*a);  %X2和X3是第2和第3个特征值的实部
          X3(i,j) = (-b + 0.5*(y1 + y2))/(3*a);
          X4(i,j) = 0.5*sqrt(3)*(y1 - y2)/(3*a); %X4是特征值的虚部，X5是X4的相反数
          X5(i,j) = -0.5*sqrt(3)*(y1 - y2)/(3*a);
       end
       if DET==0 && (A ~= 0) 
           K = (b*c-9*a*d)/(b*b - 3*a*c); 
           K = round(K,14);
           X1(i,j) = -b/a + K;  
           X2(i,j) = -0.5*K; 
           X3(i,j) = X2(i,j);
           X4(i,j) =0;
           X5(i,j)=0;
       end
       if DET < 0
           sqA = sqrt(A);
           T = (A*b - 1.5*a*B)/(A*sqA);
           theta = acos(T);
           csth  = cos(theta/3);
           sn3th = sqrt(3)*sin(theta/3);
           X1(i,j) = (-b - 2*sqA*csth)/(3*a);
           X2(i,j) = (-b + sqA*(csth + sn3th))/(3*a);
           X3(i,j) = (-b + sqA*(csth - sn3th))/(3*a);
           X4(i,j) =-1;
           X5(i,j) =1;
           clear sqA T theta csth
       end
    end
end
%% zonally symmetric equilibrium
% for i=1:1200
%     for j=1:5000
%         X1symmetry(i,j)=-1;
%         X2symmetry(i,j)=R(j)-1;
%         X3symmetry(i,j)=-sigma;
%     end
% end
%%
[R1,lam1]=meshgrid(R,lam);
%虚部消失上边界
R3=[];
lam2=[];
for i=101:1200
    for j=1:3999
        if (X4(i,j)>0)&&(X4(i,j+1)==-1)
            R3=cat(1,R3,R1(i,j));
            lam2=cat(1,lam2,lam1(i,j));
        end
    end
end
%虚部消失下边界
R5=[];
lam4=[];
for i=1:1200
    for j=1:3999
        if (X4(i,j)==-1)&&(X4(i,j+1)>0)
            R5=cat(1,R5,R1(i,j));
            lam4=cat(1,lam4,lam1(i,j));
        end
    end
end
%霍普夫分岔
RH=[];
lamH=[];
for i=1:1200
    for j=1:3999
        if (X2(i,j)<0)&&(X2(i,j+1)>0)
            RH=cat(1,RH,R1(i,j));
            lamH=cat(1,lamH,lam1(i,j));
        end
    end
end

figure
gca1=subplot(2,3,4);
[c1,h1]=contour(R1,lam1,X1,[-1,-0.9,-0.8,-0.7,-0.6],'k-','ShowText','on','linewidth',1.5,'LabelSpacing',200);
clabel(c1,h1,'fontsize',16,'fontname','Times New Roman');
xlabel('R','FontAngle','italic');
ylabel('Λ');
title('(b) eigenvalue 1 (Real)','fontname','Times New Roman');
set(gca1,'fontsize',18,'fontname','Times New Roman');
axis([1,5,0,1.2]);
yticks([0:0.4:1.2]);
set(gca1,'TickDir','both');

gca2=subplot(2,3,2);
[c2,h2]=contour(R1,lam1,X2,[-1.5,-1,-0.5,0.5,1,1.5,50],'k-','ShowText','on','linewidth',1.5,'Labelspacing',300);
clabel(c2,h2,'fontsize',16,'fontname','Times New Roman');
hold on
[c2b,h2b]=contour(R1,lam1,X2,[-100,0],'r','ShowText','on','linewidth',1.5);
clabel(c2b,h2b,'fontsize',16,'fontname','Times New Roman');
title('(c) Re(eigenvalue 2)','fontname','Times New Roman');
set(gca2,'fontsize',18,'fontname','Times New Roman');
axis([1,5,0,1.2]);
yticks([]);
xticks([]);
set(gca2,'TickDir','both');

gca3=subplot(2,3,5);
[c3,h3]=contour(R1,lam1,X3,[-1.5,-1,-0.5,0.5,1,1.5],'k-','ShowText','on','linewidth',1.5,'Labelspacing',600);
clabel(c3,h3,'fontsize',16,'fontname','Times New Roman');
hold on
[c3b,h3b]=contour(R1,lam1,X3,[-100,0],'r','ShowText','on','linewidth',1.5);
clabel(c3b,h3b,'fontsize',16,'fontname','Times New Roman');
xlabel('R','FontAngle','italic');
title('(d) Re(eigenvalue 3)','fontname','Times New Roman');
set(gca3,'fontsize',18,'fontname','Times New Roman');
axis([1,5,0,1.2]);
yticks([]);
set(gca3,'TickDir','both');

gca4=subplot(2,3,3);
fill([1:0.001:R5(1),R5',R5(end):-0.001:1,ones(1,1200)],[0.001*ones(1,398),lam4',1.2*ones(1,31),1.2:-0.001:0.001],[0.9,0.9,0.9],'linestyle','none');
hold on
fill([R3',R3(end):0.001:5,5*ones(1,905)],[lam2',1.2*ones(1,3745),1.2:-0.001:lam2(1)],[0.9,0.9,0.9],'linestyle','none');
hold on
[c4,h4]=contour(R1,lam1,X4,[0:0.5:1.5],'k','ShowText','on','linewidth',1.5,'Labelspacing',10000);
clabel(c4,h4,'fontsize',18,'fontname','Times New Roman');
hold on
plot(R3,lam2,'r--','LineWidth',2);
title('(e) Im(eigenvalue 2)','fontname','Times New Roman');
set(gca4,'fontsize',18,'fontname','Times New Roman');
axis([1,5,0,1.2]);
yticks([]);
xticks([]);

gca5=subplot(2,3,6);
fill([1:0.001:R5(1),R5',R5(end):-0.001:1,ones(1,1200)],[0.001*ones(1,398),lam4',1.2*ones(1,31),1.2:-0.001:0.001],[0.9,0.9,0.9],'linestyle','none');
hold on
fill([R3',R3(end):0.001:5,5*ones(1,905)],[lam2',1.2*ones(1,3745),1.2:-0.001:lam2(1)],[0.9,0.9,0.9],'linestyle','none');
hold on
[c5,h5]=contour(R1,lam1,X5,[-0.5,-1000],'k-','ShowText','on','linewidth',1.5,'Labelspacing',400);
clabel(c5,h5,'fontsize',16,'fontname','Times New Roman');
hold on
[c5b,h5b]=contour(R1,lam1,X5,[-1,-1000],'k-','ShowText','on','linewidth',1.5,'Labelspacing',300);
clabel(c5b,h5b,'fontsize',16,'fontname','Times New Roman');
hold on
[c5c,h5c]=contour(R1,lam1,X5,[-1.5,-1000],'k-','ShowText','on','linewidth',1.5,'Labelspacing',230);
clabel(c5c,h5c,'fontsize',16,'fontname','Times New Roman');
hold on
[c5d,h5d]=contour(R1,lam1,X5,[0,-1000],'k-','ShowText','on','linewidth',1.5,'Labelspacing',220);
clabel(c5d,h5d,'fontsize',16,'fontname','Times New Roman');
hold on
plot(R3,lam2,'r--','LineWidth',2);
xlabel('R','FontAngle','italic');
title('(f) Im(eigenvalue 3)','fontname','Times New Roman');
set(gca5,'fontsize',18,'fontname','Times New Roman');
axis([1,5,0,1.2]);
yticks([0:0.2:1.2]);
yticks([]);
set(gca5,'TickDir','both');

%回复信中加标记的的stability diagram
set(groot,'defaultAxesFontName','Times New Roman', ...
    'defaultTextFontName','Times New Roman', ...
    'defaultAxesFontSize',18, ...
    'defaultTextFontSize',18);
% figure
gca5=subplot(2,3,1);
% s=0.1,sigma=0.5
% fill([fliplr(R3'),5*ones(1,73),RH'],[fliplr(lam2'),0.201:-0.001:0.129,lamH'],[1,0.5,0.5],'linestyle', 'none');
% s=1/3,sigma=0.5
fill([fliplr(R3'),5*ones(1,198),RH',1.081:0.001:1.256],[fliplr(lam2'),0.495:-0.001:0.298,lamH',1.2*ones(1,176)],[1,0.5,0.5],'linestyle', 'none');
hold on;
plot(RH,lamH,'g','LineWidth',1);
hold on;
plot(R3,lam2,'b','LineWidth',1);

subtitle('(d) s=1/3, σ=0.2');
axis([1,5,0,1.2]);
yticks(0:0.2:1.2);
xticks(1:5);
xticklabels('{}');
yticklabels('{}');
% ylabel('Λ');
% xlabel('R');
set(gca5,'TickDir','both');
legend('Limit Cycle Regime','Hopf Bifurcation','Oscillation Stop');
sgtitle('Stability Diagram in R-Λ coordinate');
% t=0.001:0.001:5;
% y(1:5000)=sin(pi*t(1:5000)-pi/2)-1;
% for j=1:5000
%     X1symmetrya(1:1200,j)=y(j);
% end
% gca6=subplot(2,2,2);
% p=pcolor(R1,lam1,X1symmetry);
% caxis([-2,2]);
% c=colorbar;
% set(c,'ticks',[-1.5:0.5:1.5]);
% map(:,1)=[0:0.25:0.75,ones(1,3),0.9];
% map(:,2)=[0:0.25:0.75,0.75:-0.25:0];
% map(:,3)=[0.9,ones(1,3),0.75:-0.25:0];
% colormap(map);
% set(p, 'LineStyle','none');
% hold on
% [c6,h6]=contour(R1,lam1,X1symmetrya,[-100,-1],'k--','ShowText','on','linewidth',1,'Labelspacing',300);
% clabel(c6,h6,'fontsize',16,'fontname','Times New Roman');
% xlabel('R');
% ylabel('Λ');
% title('λ1','fontname','Times New Roman');
% set(gca6,'fontsize',18,'fontname','Times New Roman');
% axis([0,5,0,1.2]);
% yticks([0:0.2:1.2]);
% set(gca6,'TickDir','both');
% 
% gca7=subplot(2,2,3);
% fill([0:0.001:R5(1),R5',R5(end):-0.001:0,zeros(1,1200)],[0.001*ones(1,1398),lam4',1.2*ones(1,1031),1.2:-0.001:0.001],[0.9,0.9,0.9],'linestyle','none');
% hold on
% p=pcolor(R1,lam1,X2symmetry);
% caxis([-2,2]);
% c=colorbar;
% set(c,'ticks',[-1.5:0.5:1.5]);
% map(:,1)=[0:0.25:0.75,ones(1,3),0.9];
% map(:,2)=[0:0.25:0.75,0.75:-0.25:0];
% map(:,3)=[0.9,ones(1,3),0.75:-0.25:0];
% colormap(map);
% set(p, 'LineStyle','none');
% hold on
% [c7a,h7a]=contour(R1,lam1,X2symmetry,[-0.75,-0.5,-0.25],'k--','ShowText','on','linewidth',1,'Labelspacing',300);
% clabel(c7a,h7a,'fontsize',16,'fontname','Times New Roman');
% hold on
% [c7b,h7b]=contour(R1,lam1,X2symmetry,[0:0.5:2,3,4],'k-','ShowText','on','linewidth',1,'Labelspacing',300);
% clabel(c7b,h7b,'fontsize',16,'fontname','Times New Roman');
% xlabel('R');
% ylabel('Λ');
% title('λ2','fontname','Times New Roman');
% set(gca7,'fontsize',18,'fontname','Times New Roman');
% axis([0,5,0,1.2]);
% yticks([0:0.2:1.2]);
% set(gca7,'TickDir','both');
% 
% t=0.001:0.001:5;
% y(1:5000)=sin(pi*t(1:5000)-pi/2)-0.5;
% for j=1:5000
%     X3symmetrya(1:1200,j)=y(j);
% end
% gca8=subplot(2,2,4);
% fill([0:0.001:R5(1),R5',R5(end):-0.001:0,zeros(1,1200)],[0.001*ones(1,1398),lam4',1.2*ones(1,1031),1.2:-0.001:0.001],[0.9,0.9,0.9],'linestyle','none');
% hold on
% p=pcolor(R1,lam1,X3symmetry);
% caxis([-2,2]);
% c=colorbar;
% set(c,'ticks',[-1.5:0.5:1.5]);
% map(:,1)=[0:0.25:0.75,ones(1,3),0.9];
% map(:,2)=[0:0.25:0.75,0.75:-0.25:0];
% map(:,3)=[0.9,ones(1,3),0.75:-0.25:0];
% colormap(map);
% set(p, 'LineStyle','none');
% hold on
% [c8,h8]=contour(R1,lam1,X3symmetrya,[-100,-0.5],'k--','ShowText','on','linewidth',1,'Labelspacing',300);
% clabel(c8,h8,'fontsize',16,'fontname','Times New Roman');
% xlabel('R');
% ylabel('Λ');
% title('λ3','fontname','Times New Roman');
% set(gca8,'fontsize',18,'fontname','Times New Roman');
% axis([0,5,0,1.2]);
% yticks([0:0.2:1.2]);
% set(gca8,'TickDir','both');
